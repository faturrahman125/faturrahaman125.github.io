// s one
public int seqSearch (int a[], int len, int x) {
   for (int i = 0; i < len; i++) {
      if (a[i] == x)
      return i;
   }
   return -1;
}

// s two
int binarySearch(int a[], int x, int low, int high) {
   if (low > high) // Base Case 1: item not found
   return -1;

   int mid = (low+high) / 2;

   if (x > a[mid])
   return binarySearch (a, x, mid+1, high);
   else if (x < a[mid])
   return binarySearch(a, x, low, mid-1);
   else
   return mid; // Base case 2: item found
}

// s 3
int binSearch(int a[], int len, int x) {
   int mid, low = 0;
   int high = len-1;

   while (low <= high) {
      mid + (low+high) / 2;
      if (x == a[mid])
      return mid;
      else if (x > a[mid])
      low = mid+1;
      else
      high = mid-1;
   }
   return -1;
}

void f(int n) {
   if (n > 0) {
      DoSomething (n) ; // O(n)
      f(n/2) ; f(n/2);
   }
}

int sum = 0;
for (int i = 1; i <= n; i = i*3)
   for (int j = 1; j <= i; j++) 
      sum++;


void f(int n) {
   if (n > 0) {
      DoSomething (); // o(1)
      f(n - 1); f(n-1);
   }
}
